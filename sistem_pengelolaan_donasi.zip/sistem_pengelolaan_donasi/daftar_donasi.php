<?php
include ('header.php');
include ('koneksi.php');
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Daftar Donasi</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <style>
        table a {
            text-decoration: none;
            color: black;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h1>Daftar Pesanan</h1>
        <table class="table-striped table rounded">
            <thead>
                <tr>
                    <th scope="col">Nama</th>
                    <th scope="col">Bentuk Donasi</th>
                    <th scope="col">Jumlah Peserta</th>
                    <th scope="col">Jumlah Donasi</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $result = mysqli_query($conn, "SELECT * FROM pesanan");
            if (!$result) {
                die("Query Error: " . mysqli_error($conn));
            }
            while ($row = mysqli_fetch_assoc($result)) {
                // Harga paket
                $harga_sapi = 10000000;
                $harga_kambing = 5000000;
                $harga_makanan = 500000;

                // Mengambil paket yang dipilih
                $pilihan = explode(",", $row['pilihan']);

                $harga_paket = 0;
                foreach ($pilihan as $paket) {
                    if ($paket == "sapi") {
                        $harga_paket += $harga_sapi;
                    } elseif ($paket == "kambing") {
                        $harga_paket += $harga_kambing;
                    } elseif ($paket == "makanan") { // Pastikan konsistensi penamaan
                        $harga_paket += $harga_makanan;
                    }
                }

                // Hitung jumlah tagihan
                $jumlah_tagihan = $harga_paket * $row['jumlah_peserta'];

                echo "<tr>";
                echo "<