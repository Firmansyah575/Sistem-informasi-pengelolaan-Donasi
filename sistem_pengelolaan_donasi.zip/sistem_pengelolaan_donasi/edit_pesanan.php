<?php
include ("header.php");
include ('koneksi.php');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0; // Validasi ID
$result = mysqli_query($conn, "SELECT * FROM pesanan WHERE id = $id");

if (!$result) {
    die("Query Error: " . mysqli_error($conn));
}

$row = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $nama = $_POST['nama'];
    $bentuk_donasi = $_POST['bentuk_donasi']; // Perbaiki penamaan variabel
    $jumlah_peserta = $_POST['jumlah_peserta'];

    // Validasi input
    if (empty($nama) || empty($bentuk_donasi) || empty($jumlah_peserta)) {
        echo "Semua field harus diisi.";
    } else {
        // Query untuk update data
        $updateQuery = "UPDATE pesanan SET nama = ?, bentuk_donasi = ?, jumlah_peserta = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'ssii', $nama, $bentuk_donasi, $jumlah_peserta, $id);

        if (mysqli_stmt_execute($stmt)) {
            header('Location: daftar_pesanan.php');
            exit;
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Edit Pesanan</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</head>

<body>
    <div class="container mt-5">
        <h2>Edit Pesanan</h2>
        <form method="post">
            <label for="nama" class="form-check-label">Nama:</label>
            <input type="text" id="nama" name="nama" value="<?= htmlspecialchars($row['nama']) ?>" class="form-control"><br>
            <label for="bentuk_donasi" class="form-check-label">Bentuk Donasi:</label>
            <input type="text" id="bentuk_donasi" name="bentuk_donasi" value="<?= htmlspecialchars($row['bentuk_donasi']) ?>" class="form-control"><br>
            <label for="jumlah_peserta" class="form-check-label">Jumlah Peserta:</label>
            <input type="number" id="jumlah_peserta" name="jumlah_peserta" value="<?= htmlspecialchars($row['jumlah_peserta']) ?>" class="form-control"><br>

            <button type="submit" class="btn btn-primary mt-5">Update</button>
        </form>
    </div>
    <?php include ("footer.php") ?>
</body>

</html>