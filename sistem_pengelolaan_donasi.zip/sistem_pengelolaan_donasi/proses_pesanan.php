<?php
include('header.php');  
include('koneksi.php');  

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil dan bersihkan input
    $nama = htmlspecialchars(trim($_POST['nama']));
    $bentuk_donasi = htmlspecialchars(trim($_POST['bentuk_donasi']));
    $jumlah_peserta = (int)$_POST['jumlah_peserta']; // Pastikan ini adalah integer
    $pilihan = isset($_POST['pilihan']) ? $_POST['pilihan'] : [];

    // Validasi input
    if (empty($nama) || empty($bentuk_donasi) || $jumlah_peserta <= 0) {
        echo "<script>alert('Semua field harus diisi dengan benar!'); window.history.back();</script>";
        exit;
    }

    // Daftar harga paket
    $harga_paket = [
        "sapi" => 10000000,
        "kambing" => 5000000,
        "makanan" => 500000 // Pastikan konsistensi penamaan
    ];

    // Menghitung jumlah tagihan berdasarkan pilihan paket
    $jumlah_tagihan = 0;
    $pilihan_str = "";

    if (!empty($pilihan)) {
        foreach ($pilihan as $pilih) {
            $jumlah_tagihan += $harga_paket[strtolower($pilih)] ?? 0; // Pastikan konsistensi penamaan
        }
        $pilihan_str = implode(", ", $pilihan);
    }

    // Query untuk memasukkan data pesanan ke database
    $stmt = $conn->prepare("INSERT INTO pesanan (nama, bentuk_donasi, jumlah_peserta, pilihan, jumlah_tagihan) 
                             VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiss", $nama, $bentuk_donasi, $jumlah_peserta, $pilihan_str, $jumlah_tagihan);

    if ($stmt->execute()) {
        echo "<script>alert('Pemesanan berhasil!'); window.location.href='index.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>